(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5389:
/***/ ((module) => {

// Exports
module.exports = {
	"Footer": "Footer_Footer__6FjgE"
};


/***/ }),

/***/ 781:
/***/ ((module) => {

// Exports
module.exports = {
	"Header": "Header_Header__anYqz",
	"Nav": "Header_Nav__qPVMQ",
	"NavWrapper": "Header_NavWrapper__Y3W3o",
	"NavList": "Header_NavList__oOe2L"
};


/***/ }),

/***/ 2966:
/***/ ((module) => {

// Exports
module.exports = {
	"MobileNav": "MobileNav_MobileNav__x5Vaq",
	"NavList": "MobileNav_NavList__UASYT",
	"Open": "MobileNav_Open__25vd9"
};


/***/ }),

/***/ 7046:
/***/ ((module) => {

// Exports
module.exports = {
	"Logo": "Logo_Logo__cFm0r"
};


/***/ }),

/***/ 6243:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/layout/footer/Footer.module.css
var Footer_module = __webpack_require__(5389);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/layout/footer/Footer.js



const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: (Footer_module_default()).Footer,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "REPLASTIC D.O.O. 2022 \xa9 SVA PRAVA ZADRŽANA. "
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/politika-privatnosti",
                    children: "Politika privatnosti"
                })
            ]
        })
    });
};
/* harmony default export */ const footer_Footer = (Footer);

;// CONCATENATED MODULE: ./components/ui/NavLink.js


const NavLink = ({ children , setOpen , href  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        onClick: ()=>setOpen(false),
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: `/${href}`,
            children: children
        })
    });
};
/* harmony default export */ const ui_NavLink = (NavLink);

;// CONCATENATED MODULE: external "hamburger-react"
const external_hamburger_react_namespaceObject = require("hamburger-react");
var external_hamburger_react_default = /*#__PURE__*/__webpack_require__.n(external_hamburger_react_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./utils/utils.js
var utils = __webpack_require__(5244);
// EXTERNAL MODULE: ./components/ui/Logo.module.css
var Logo_module = __webpack_require__(7046);
var Logo_module_default = /*#__PURE__*/__webpack_require__.n(Logo_module);
;// CONCATENATED MODULE: ./components/ui/Logo.js





const Logo = ()=>{
    const width = utils/* isWindow */.F && window.innerWidth < 768 ? 125 : 150;
    const height = utils/* isWindow */.F && window.innerWidth < 768 ? 26 : 31;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Logo_module_default()).Logo,
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: "/",
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: "/logo.png",
                width: width,
                height: height,
                alt: "logo-image"
            })
        })
    });
};
/* harmony default export */ const ui_Logo = (Logo);

// EXTERNAL MODULE: ./pageData/data.js
var data = __webpack_require__(871);
// EXTERNAL MODULE: ./components/layout/header/Header.module.css
var Header_module = __webpack_require__(781);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
// EXTERNAL MODULE: ./components/layout/header/MobileNav.module.css
var MobileNav_module = __webpack_require__(2966);
var MobileNav_module_default = /*#__PURE__*/__webpack_require__.n(MobileNav_module);
;// CONCATENATED MODULE: ./components/layout/header/MobileNav.js




const MobileNav = ({ setOpen , isOpen  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `${(MobileNav_module_default()).MobileNav} ${isOpen ? (MobileNav_module_default()).Open : ""}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            className: (MobileNav_module_default()).Nav,
            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: (MobileNav_module_default()).NavList,
                children: data/* NAV_LINKS.map */.q.map(({ name , id , href  })=>/*#__PURE__*/ jsx_runtime_.jsx(ui_NavLink, {
                        href: `#${href}`,
                        setOpen: setOpen,
                        children: name
                    }, id))
            })
        })
    });
};
/* harmony default export */ const header_MobileNav = (MobileNav);

;// CONCATENATED MODULE: ./components/layout/header/Header.js








const Header = ()=>{
    const [isOpen, setOpen] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: `${(Header_module_default()).Header} container`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Header_module_default()).NavWrapper,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ui_Logo, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                        className: (Header_module_default()).Nav,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: (Header_module_default()).NavList,
                            children: data/* NAV_LINKS.map */.q.map(({ name , id , href  })=>/*#__PURE__*/ jsx_runtime_.jsx(ui_NavLink, {
                                    href: `#${href}`,
                                    setOpen: setOpen,
                                    children: name
                                }, id))
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(header_MobileNav, {
                        isOpen: isOpen,
                        setOpen: ()=>{
                            setOpen(false);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((external_hamburger_react_default()), {
                toggled: isOpen,
                toggle: setOpen
            })
        ]
    });
};
/* harmony default export */ const header_Header = (Header);

;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
;// CONCATENATED MODULE: ./components/layout/Layout.js





const Layout = ({ children  })=>{
    const { pathname  } = (0,router_namespaceObject.useRouter)();
    const isPrivacyPolicyPage = pathname === "/privacy-policy";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            }),
            !isPrivacyPolicyPage && /*#__PURE__*/ jsx_runtime_.jsx(footer_Footer, {})
        ]
    });
};
/* harmony default export */ const layout_Layout = (Layout);

// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: ./components/lib/gtag.js
const pageview = (url)=>{
    if (url === "/politika-privatnosti") return;
    window.gtag("config", process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS, {
        page_path: url
    });
};
const gtag_event = ({ action , category , label , value  })=>{
    window.gtag("event", action, {
        event_category: category,
        event_label: label,
        value
    });
};

;// CONCATENATED MODULE: ./pages/_app.js







const MyApp = ({ Component , pageProps  })=>{
    const router = (0,router_namespaceObject.useRouter)();
    (0,external_react_.useEffect)(()=>{
        const handleRouteChange = (url)=>{
            pageview(url);
        };
        router.events.on("routeChangeComplete", handleRouteChange);
        return ()=>{
            router.events.off("routeChangeComplete", handleRouteChange);
        };
    }, [
        router.events
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "afterInteractive",
                src: `https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "google-analytics",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}', {
          page_path: window.location.pathname,
        });
      `
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layout_Layout, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    });
};
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports =
   false
    ? 0
    : __webpack_require__(3573)


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,675,939], () => (__webpack_exec__(6243)));
module.exports = __webpack_exports__;

})();