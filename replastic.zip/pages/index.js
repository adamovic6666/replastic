import Homepage from "../components/pages/Homepage";

const Home = () => <Homepage />;

export default Home;
