const Input = () => {
  return (
    <div>
      <label htmlFor=""></label>
      <input />
    </div>
  );
};

export default Input;
