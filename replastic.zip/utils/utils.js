export const isWindow = typeof window !== "undefined";
