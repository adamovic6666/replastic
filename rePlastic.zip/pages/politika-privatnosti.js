import PrivacyPolicy from "../components/pages/PrivacyPolicy";

const Privacy = () => <PrivacyPolicy />;

export default Privacy;
