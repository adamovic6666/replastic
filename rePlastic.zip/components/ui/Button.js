const Button = ({ onClick }) => <button onClick={onClick}>Button</button>;

export default Button;
