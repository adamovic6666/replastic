const Card = ({ children }) => <div>{children}</div>;

export default Card;
